# Importar las librerías necesarias
# selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
# bs4
from bs4 import BeautifulSoup
import pandas as pd
# time
import time

# Clase Rava para obtener datos de la página web de Rava
class Rava():    

    # Método para configurar el webdriver de Selenium
    def setup(self, headless, download_dir, ticker):
        options = webdriver.ChromeOptions()
        # Configurar el webdriver en modo headless si la opción headless es True
        if headless: 
            options.add_argument('headless')
        # Configurar la ruta de descarga para el webdriver
        options.add_experimental_option('prefs', {
                'download.default_directory' : 
                 download_dir
            })
        # Crear una instancia del webdriver
        self.driver = webdriver.Chrome("C:\dchrome\chromedriver.exe", options=options)  
        self.driver.implicitly_wait(5)
        # Construir y cargar la URL en el webdriver
        url = f"https://www.rava.com/perfil/{ ticker }"
        self.driver.get(url)
        print(url)
        # Maximizar la ventana del navegador
        self.driver.maximize_window()

    # Método para hacer clic en un elemento
    def click(self, by, string):
        WebDriverWait(self.driver, 2).until(
            EC.element_to_be_clickable((by, string))).click()

    # Método para descargar los datos de precios
    def download_price(self):
        # Desplazarse hacia abajo en la página
        self.driver.execute_script("window.scrollTo(0, 700)") 
        time.sleep(3)
        # Hacer clic en el enlace "Bajar en formato Excel"
        self.click(By.XPATH, "//*[text()='Bajar en formato Excel']") 
        
    # Método para obtener el flujo de efectivo de la tabla en la página web
    def get_cash_flow(self):
        # Obtener el código fuente de la página
        html = self.driver.page_source
        # Crear un objeto BeautifulSoup
        soup = BeautifulSoup(html, "lxml")
        
        # Encontrar la tabla con el flujo de efectivo
        table = soup.find_all('div', {'id':'Flujos'})
        table = table[0]
        
        # Extraer los encabezados de la tabla
        headers = []
        for i in table.find_all('th'):
            title = i.text
            headers.append(title)

        # Crear un DataFrame vacío con los encabezados extraídos
        df = pd.DataFrame(columns=headers)
        
        # Rellenar el DataFrame con los datos de las filas de la tabla
        for row in table.find_all('tr')[1:]:
            data = row.find_all('td')
            row_data = [td.text.strip() for td in data]
            length = len(df)
            df.loc[length] = row_data
            
        return df

    # Método para cerrar el webdriver
    def finish(self):
        # Volver a la página anterior
        self.driver.back()
        # Intentar aceptar una alerta si está presente
        try:
            alert = self.driver.switch_to.alert
            alert.accept()
        except:
            pass
        time.sleep(1)
        # Cerrar el webdriver
        self.driver.quit()