from Tradingview import Tradingview
import pandas as pd
import sys
import time
import os

# Configuration 

valid_freq = ["1", "2", "3", "5", "10", "30", "45", "60", 
                         "120", "240", "1D", "1W", "1M" ]

output_dir = r"C:\Users\Federico Navos\Desktop\Python\tradingview\output"  

# Read args
nro_args = len(sys.argv) - 1

if nro_args >= 4:
    download_dir = sys.argv[4]
else:
    download_dir = r"C:\Users\Federico Navos\Desktop\Python\tradingview\downloads"

files = os.listdir(download_dir)
file = download_dir + '\\' + files[0]
df = pd.read_csv(file, index_col=None)
name = 'IMVUSD'
name = name + '-' + '60' + '.xlsx'
df.to_excel(output_dir + '\\' + name , index=None)
os.remove(file)
