from Rava import Rava
import pandas as pd
import sys
import time
import os
import numpy as np

# Configuración
tickers = ["AL30", "AL30D"]

output_dir = r"C:\Users\Federico Navos\Desktop\Python\rava\output"  

# Leer argumentos
nro_args = len(sys.argv) - 1

if nro_args >= 4:
    download_dir = sys.argv[4]
else:
    download_dir = r"C:\Users\Federico Navos\Desktop\Python\rava\downloads"  

if nro_args >= 3 and sys.argv[3] == "1":
    headless = True
else:    
    headless = False

# Inicio del programa
rava = Rava()

# Eliminar archivos existentes en el directorio de descarga
for file in os.listdir(download_dir):
    os.remove(download_dir + '\\' + file)

# Iterar a través de los tickers
for ticker in tickers: 
    rava.setup(headless, download_dir, ticker)
    time.sleep(5)
    
    print(ticker)
    name = ticker + '.xlsx'
    
    time.sleep(5)
    rava.download_price()
    time.sleep(2)
    
    # Leer y procesar el archivo descargado
    files = os.listdir(download_dir)
    file = download_dir + '\\' + files[0]
    df = pd.read_csv(file, index_col=None)
    
    # Guardar el archivo en formato Excel en el directorio de salida
    df.to_excel(output_dir + '\\' + name, index=None)
    
    # Eliminar el archivo descargado
    os.remove(file)
    
    name = ticker + '-CF.xlsx'
    
    # Obtener y procesar el flujo de efectivo
    df2 = rava.get_cash_flow()
    df2 = df2.replace('-', np.nan)
    df2['Renta'] = df2['Renta'].replace(',','.', regex=True).values
    df2['Cupón'] = df2['Cupón'].replace(',','.', regex=True).values
    df2['Amort.'] = df2['Amort.'].replace(',','.', regex=True).values
    
    # Guardar el flujo de efectivo en formato Excel en el directorio de salida
    df2.to_excel(output_dir + '\\' + name, index=None)
    
    rava.finish()