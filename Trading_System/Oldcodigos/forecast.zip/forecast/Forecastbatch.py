# Importar las librerías necesarias
from Forecast import Forecast
import pandas as pd
import sys
import time
from datetime import datetime
from pandas.tseries.offsets import MonthEnd

# Configuración
tickers = ["nasd", "ffund", "10yrT", "stpoor", "djfuture", 
           "euro", "gold", "dollar-forecast", "oil", "djia", "inflation"]
especies = ["NASDAQ", "FEDFUND", "US10Y", "STPOOR", "COMMOD", 
            "EURUSD", "GOLD", "DXY", "OIL", "DOWJ", "INFLATION"]

# Ruta de salida para los archivos generados
output_dir = r"C:\Users\Federico Navos\Desktop\Python\forecast\output"  

# Leer argumentos
nro_args = len(sys.argv) - 1

# Establecer la ruta de descarga en función de los argumentos
if nro_args >= 4:
    download_dir = sys.argv[4]
else:
    download_dir = r"C:\Users\Federico Navos\Desktop\Python\forecast\downloads"  

# Establecer la opción de ejecución sin cabeza en función de los argumentos
if nro_args >= 3 and sys.argv[3] == "1":
    headless = True
else:    
    headless = False

# Inicio del programa

# Crear una instancia de la clase Forecast
forecast = Forecast()

# Iterar sobre los tickers y obtener las predicciones
for i, ticker in enumerate(tickers): 
    forecast.setup(headless, download_dir, ticker)
    time.sleep(1)

    try:
        # Obtener la fecha de la predicción y convertirla a objeto datetime
        prediction_date = forecast.get_date_prediction()
        prediction_date = datetime.strptime(prediction_date, "%Y-%m-%d")
        print(prediction_date)

        print(ticker)
        print(especies[i])
        name = especies[i] + '_' + prediction_date.strftime("%d%m%Y") + '_FCAST.xlsx'

        time.sleep(1)
        # Obtener el DataFrame con las predicciones
        df = forecast.get_predictions()
        time.sleep(1)
        # Guardar el DataFrame en un archivo Excel
        df.to_excel(output_dir + '\\' + name, index=None)
        print(name + " DOWNLOADED")

        # Formatear y procesar el DataFrame
        df['Date'] = pd.to_datetime(df['Date']) + MonthEnd(1)
        df['Avg Error'] = df['Avg Error'].str[1:]
        df['error'] = pd.to_numeric(df['Avg Error'])
        df['Forecast Value'] = pd.to_numeric(df['Forecast Value'])

        df['especie'] = especies[i] + '_FCAST'
        df['time'] = df['Date']
        df['fuente'] = 'Forecast'
        df['open'] = df['Forecast Value']
        df['close'] = df['Forecast Value']
        df['fechaDato'] = prediction_date
        df['tipoDato'] = 'Valor'
        df['low'] = df['Forecast Value'] - df['error']
        df['high'] = df['Forecast Value'] + df['error']

        # Seleccionar las columnas necesarias del DataFrame
        df = df[['especie', 'time', 'fuente', 'open', 'close', 'high', 'low', 'fechaDato', 'tipoDato']]

        with open("./lastUpdated/" + especies[i] + "_lastUpdated.txt", "w") as f:
            print(prediction_date.strftime("%d-%m-%Y"))
            f.write(prediction_date.strftime("%d-%m-%Y"))
        
        name = especies[i] + '_' + prediction_date.strftime("%d-%m-%Y") + '_FCAST_FORMATTED.xlsx'
        df.to_excel(output_dir + '\\' + name, index=None)
    except Exception as e: 
        print(e)
    finally:
        forecast.finish()